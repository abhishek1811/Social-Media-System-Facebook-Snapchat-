var contentDiv = document.getElementById('content');

for (var i = 0; i < 12; i++) {
	var tmpl = document.getElementById('photo-template').content.cloneNode(true);
	$("#content").append(tmpl) //.slideDown('slow');
}

$("#globalName").text(sessvars.usernameInput);
$(document).ready(function() {

	$('#window-overlay').css('height', parseFloat($('#content').css('height')) + 75 + 'px');
	
	//$('#photo-overlay').css('height', );

	$('.template-border').click(function() {
		
		$('#window-overlay').css('visibility', 'visible').animate({opacity: 1}, 100);
	
	});
	
	$('#window-overlay').on('click', function(e) {
		
		// if statement stops function from firing on child click
		if(e.target !== this) {
			return;
		}
		
		$('#window-overlay').animate({opacity: 0}, 100);
		$('#window-overlay').css('visibility', 'hidden');
		
	});

});

// overlay dynamic card sizes
$(document).ready(function() {
	var tBorder = $('#photo-overlay');
	var bWidth = tBorder.width();
	
	var tPhotoHolder = $('#photo-overlay-holder');
	
	tBorder.css('height', 1.5*bWidth);
	tPhotoHolder.css('height', bWidth);
	
	var holderHeight = tPhotoHolder.height();
	
	tPhotoHolder.css('line-height', holderHeight + "px");
	
	var q = $('#photo-overlay-question-mark');
	q.css('font-size', (holderHeight * 0.5) + "px");
});

$(window).resize(function() {
    var tBorder = $('#photo-overlay');
	var bWidth = tBorder.width();
	
	var tPhotoHolder = $('#photo-overlay-holder');
	
	tBorder.css('height', 1.5*bWidth);
	tPhotoHolder.css('height', bWidth);
	
	var holderHeight = tPhotoHolder.height();
	
	tPhotoHolder.css('line-height', holderHeight + "px");
	
	var q = $('#photo-overlay-question-mark');
	q.css('font-size', (holderHeight * 0.5) + "px");
	
});
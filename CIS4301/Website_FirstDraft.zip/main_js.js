var pass = document.getElementById("passwordInput");

pass.addEventListener("keydown", function (e) {
    if (e.keyCode === 13) {
        validate(e);
    }
});

$("#usernameInput").keyup(function() {
	sessvars.usernameInput = $(this).val();
});

function validate(e) {
    window.location.href='file://localhost/Applications/MAMP/htdocs/CIS4301/loggedIn.html';
}